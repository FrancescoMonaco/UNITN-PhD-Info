# The LaTeX template for the Qualifying Exam Report 

This folder contains a template for the report to be produced for the Qualifying Exam for the IECS PhD School of the Department of Computer Science Engineering of the University of Trento.

It shows the mandatory sections expected in the report. 

The template can use either BibTex or Biblatex to generate automatically the bibliography.
Edit the preamble of the 'main.tex' file and comment/uncomment one of the following two lines

```
\usebiblatextrue % Set to true to use BibLaTeX, false to use BibTeX
%\usebiblatexfalse % Uncomment this line to use BibTeX
```

Author: Marco Roveri <marco.roveri@unitn.it>

-----------
Original archive content:
```
.
|____acmart.cls
|____biblio-fileone.bib
|____acmnumeric.bbx
|____figs
| |____Example-of-a-3-year-PhD-timeline.png
|____main.tex
|____README.md
|____ACM-Reference-Format.bst
|____biblio-filetwo.bib
|____example.pdf
|____acmnumeric.cbx
```
